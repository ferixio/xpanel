
<div class="uk-width-1-1" style="max-height:30px;padding-bottom:100px;">
 <p class="uk-text-meta uk-text-center uk-margin-large-top  x-font-12" >supported by <a href="http://www.xitfoundation.com" target="_blank"><b>XIT foundation</b></a></p>
</div>