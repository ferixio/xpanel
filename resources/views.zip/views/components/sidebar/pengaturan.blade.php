<li><a href="{{ url('xpanel/setting/company-profile') }}">Company Profile</a></li>
{{-- <li><a href="{{ url('#') }}">Website</a></li> --}}