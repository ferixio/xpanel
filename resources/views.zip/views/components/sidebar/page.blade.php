<li><a href="{{ url('#') }}">Homepage</a></li>
<li><a href="{{ url('#') }}">Product</a></li>
<li><a href="{{ url('#') }}">Product Detail</a></li>
<li><a href="{{ url('#') }}">About Us</a></li>
<li><a href="{{ url('#') }}">Contact Us</a></li>