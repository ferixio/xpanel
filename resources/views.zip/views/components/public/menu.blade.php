

<li class="uk-padding-small"><a href="{{url('/')}}" class=" x-font-16 x-color-theme-public-text uk-button-text">Home</a></li>
<li class="uk-padding-small"><a href="{{url('product')}}" class=" x-font-16 x-color-theme-public-text uk-button-text">Product</a></li>
<li class="uk-padding-small"><a href="{{url('article')}}" class=" x-font-16 x-color-theme-public-text uk-button-text">Sweet Story</a></li>
<li class="uk-padding-small"><a href="{{url('tentang-kami')}}" class=" x-font-16 x-color-theme-public-text uk-button-text">About Us</a></li>
<li class="uk-padding-small"><a href="{{url('kontak-kami')}}" class=" x-font-16 x-color-theme-public-text uk-button-text">Contact Us</a></li>