<div id="slideshow"  class="uk-visible-toggle uk-position-relative uk-animation-toggle" uk-slideshow="autoplay: true; autoplay-interval: 3500; pause-on-hover: false;ratio: 7:3;animation:push;">
  <ul class="uk-slideshow-items">
    <li>
      <img data-src="{{asset('storage/uploads/slideshow/5.jpg')}}" alt="" srcset="" uk-img uk-cover>
    </li>
    <li>
      <img data-src="{{asset('storage/uploads/slideshow/1.jpg')}}" alt="" srcset="" uk-img uk-cover>
    </li>
    <li>
      <img data-src="{{asset('storage/uploads/slideshow/2.jpg')}}" alt="" srcset="" uk-img uk-cover>
    </li>
    <li>
      <img data-src="{{asset('storage/uploads/slideshow/3.jpg')}}" alt="" srcset="" uk-img uk-cover>
    </li>
    <li>
      <img data-src="{{asset('storage/uploads/slideshow/4.jpg')}}" alt="" srcset="" uk-img uk-cover>
    </li>
    
  </ul>
  <ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul>
  <a class="uk-position-center-left uk-overlay uk-overlay-default uk-animation-fade    uk-hidden-hover uk-position-small " href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
  <a class="uk-position-center-right  uk-overlay uk-overlay-default  uk-animation-fade  uk-hidden-hover uk-position-small" href="#" uk-slidenav-next uk-slideshow-item="next"></a>

</div>