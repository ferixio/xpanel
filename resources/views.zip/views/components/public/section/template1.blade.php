<section class="uk-container">
  <div>
    <div class="uk-child-width-1-1 uk-child-width-1-2@m uk-position-relative uk-margin-xlarge-top" style="background: #F6E8E8;">
      <div class="uk-padding" >
          <h2 class="uk-text-bold" uk-scrollspy>The Best Brownies</h2>
          <div class="x-font-18 uk-text-secondary"> 
            <p class="uk-text-bold">Selamat Datang di Website Sugar Pastry
              A Trully Brownies Taste</p>

              <p>Sugar Pastry Brownies Kukus, sebuah nama yang melegenda
                di hati masyarakat, khususnya masyarakat pecinta kuliner,
                tidak hanya Pati tapi seluruh Indonesia.</p>
                
                <p>Brownies Sugar Pastry, sebuah keseimbangan antara komitmen dan karya.</p>
              </div>
        
      </div>
      <div>
        <img data-src="{{asset('storage/uploads/page/home1.png')}}" alt="" srcset="" uk-img class="uk-position-center-right uk-visible@m">
        <img data-src="{{asset('storage/uploads/page/home1.png')}}" alt="" srcset="" uk-img class="uk-hidden@m">
      </div>
  </div>
  </div>
</section>